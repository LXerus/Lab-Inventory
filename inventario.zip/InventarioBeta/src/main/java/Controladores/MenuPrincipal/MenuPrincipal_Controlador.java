package Controladores.MenuPrincipal;

import Clases.Conexion;
import Clases.Modelos.UsuarioActual;
import Controladores.Bodegas.MenuBodegas_Controlador;
import Controladores.Productos.MenuProductos_Controlador;
import Controladores.Proveedores.MenuProveedores_Controlador;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;

public class MenuPrincipal_Controlador implements Initializable {
     @FXML
     private BorderPane panel_menu_principal;
     @FXML
     private Button menu_principal_btn_salir;
     @FXML
     private Label menu_principal_label_usuario;
     @FXML
     private Label menu_principal_label_id;
     @FXML
     private Label menu_principal_label_area;
     @FXML
     private Label menu_principal_label_email;
     @FXML
     private Label menu_principal_label_privilegios;

    private FXMLLoader fxmlLoader;
    private AnchorPane panel_menu_seleccionado;
    private MenuBodegas_Controlador menuBodegasControlador;
    private MenuProductos_Controlador menuProductosControlador;
    private MenuProveedores_Controlador menuProveedoresControlador;
    private static BorderPane panelPadre;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        menu_principal_label_usuario.setText(UsuarioActual.getUsuarioActual().getNombres());
        menu_principal_label_id.setText(String.valueOf(UsuarioActual.getUsuarioActual().getId()));
        menu_principal_label_area.setText(UsuarioActual.getUsuarioActual().getArea());
        menu_principal_label_email.setText(UsuarioActual.getUsuarioActual().getCorreo_electronico());
        menu_principal_label_privilegios.setText(UsuarioActual.getUsuarioActual().getPrivilegios());
    }


    public void salir(){
        Stage stage = (Stage) menu_principal_btn_salir.getScene().getWindow();
        stage.close();
    }

    public void testConnection(){
        Conexion conexion = new Conexion();
        Connection connection = conexion.getConnection();

    }

    public static BorderPane obntenerPanelPadre(){
        return panelPadre;
    }

    public Stage crearMenuPrincipal(Stage stage) throws IOException {
        panelPadre = FXMLLoader.load(getClass().getResource("/gui/Menus/menu_principal_gui.fxml"));
        stage.setTitle("Inventario");
        stage.setScene(new Scene(panelPadre, 1075, 650));
        stage.show();
        return stage;
    }

    public void irMenuProductos() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Menus/menu_productos_gui.fxml"));
        panel_menu_seleccionado = fxmlLoader.load();
        panelPadre.setCenter(panel_menu_seleccionado);
    }

    public void irMenuBodegas() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Menus/menu_bodegas_gui.fxml"));
        panel_menu_seleccionado = fxmlLoader.load();
        panelPadre.setCenter(panel_menu_seleccionado);
    }

    public void irMenuProveedores() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Menus/menu_proveedores_gui.fxml"));
        panel_menu_seleccionado = fxmlLoader.load();
        panelPadre.setCenter(panel_menu_seleccionado);
    }

    public void menuUsuarios() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Menus/menu_usuarios_gui.fxml"));
        panel_menu_seleccionado = fxmlLoader.load();
        panelPadre.setCenter(panel_menu_seleccionado);
    }

}
