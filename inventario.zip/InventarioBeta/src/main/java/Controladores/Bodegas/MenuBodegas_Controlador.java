package Controladores.Bodegas;

import Controladores.MenuPrincipal.MenuPrincipal_Controlador;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MenuBodegas_Controlador implements Initializable {
    //Panel
    @FXML
    AnchorPane panel_menu_bodegas;

    //Loader
    FXMLLoader fxmlLoader;

      //Paneles
    AnchorPane panel_buscar_bodegas;
    AnchorPane panel_registrar_bodega;

    //Controladores
    BuscarBodega_Controlador buscarBodegaControlador;
    MenuPrincipal_Controlador menuPrincipalControlador;
    RegistrarBodega_Controlador registrarBodegaControlador;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void irBuscarBodega() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Formularios/buscar_bodega_gui.fxml"));
        panel_buscar_bodegas = fxmlLoader.load();
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_buscar_bodegas);
  }

  public void irRegistrarBodega() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Formularios/registrar_bodega_gui.fxml"));
        panel_registrar_bodega = fxmlLoader.load();
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_registrar_bodega);
  }
}
