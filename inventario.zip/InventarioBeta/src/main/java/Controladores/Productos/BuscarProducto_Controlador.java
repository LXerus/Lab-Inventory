package Controladores.Productos;

import Clases.Cruds.Productos_Crud;
import Clases.Modelos.Producto;
import Controladores.MenuPrincipal.MenuPrincipal_Controlador;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class BuscarProducto_Controlador implements Initializable {
    private FXMLLoader fxmlLoader;
    private Productos_Crud productosCrud = new Productos_Crud();
    private AnchorPane panel_seleccionado;
    @FXML
    private AnchorPane panel_buscar_producto;


    @FXML
    private TextField buscar_producto_txtfl_nombre;
    @FXML
    private TextField buscar_producto_txtfl_marca;
    @FXML
    private TextField buscar_producto_txtfl_lote;
    @FXML
    private TextField buscar_producto_txtfl_factura;
    @FXML
    private TextField buscar_producto_txtfl_cas;
    @FXML
    private TextField buscar_producto_txtfl_codinterno;
    @FXML
    private TextField buscar_producto_txtfl_codstandard;

    @FXML
    private ComboBox buscar_producto_cmbox_prov;
    @FXML
    private ComboBox buscar_producto_cmbox_bodega;

    @FXML
    private DatePicker buscar_producto_dtpcker_ingreso;
    @FXML
    private DatePicker buscar_producto_dtpcker_vence;

    @FXML
    private TableView<Producto> buscar_producto_table_lista_productos;
    @FXML
    private TableColumn<Producto, Integer> producto_cl_id;
    @FXML
    private TableColumn<Producto, String> producto_cl_nombre;
    @FXML
    private TableColumn<Producto, String> producto_cl_marca;
    @FXML
    private TableColumn<Producto, String> producto_cl_bodega;
    @FXML
    private TableColumn<Producto, String> producto_cl_cas;
    @FXML
    private TableColumn<Producto, String> producto_cl_cod_interno;
    @FXML
    private TableColumn<Producto, String> producto_cl_cod_stnd;
    @FXML
    private TableColumn<Producto, String> producto_cl_lote;
    @FXML
    private TableColumn<Producto, LocalDate> producto_cl_fingreso;
    @FXML
    private TableColumn<Producto, LocalDate> producto_cl_fvencimiento;
    @FXML
    private TableColumn<Producto, LocalDate> producto_cl_fabierto;
    @FXML
    private TableColumn<Producto, String> producto_cl_presentacion;
    @FXML
    private TableColumn<Producto, Integer> producto_cl_stock;
    @FXML
    private TableColumn<Producto, Double> producto_cl_costo;
    @FXML
    private TableColumn<Producto, String> producto_cl_proveedor;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        buscar_producto_cmbox_prov.setItems(productosCrud.obtenerProveedores());
        buscar_producto_cmbox_bodega.setItems(productosCrud.obtenerListaDeBodegas());
    }

    public void cancelar() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Menus/menu_productos_gui.fxml"));
        panel_seleccionado = fxmlLoader.load();
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_seleccionado);
    }

    public void buscarProducto(){
        buscar_producto_table_lista_productos.setItems(productosCrud.buscarProductos(datosIntroducidos()));
        producto_cl_id.setCellValueFactory(new PropertyValueFactory<>("id"));
        producto_cl_nombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        producto_cl_marca.setCellValueFactory(new PropertyValueFactory<>("marca"));
        producto_cl_bodega.setCellValueFactory(new PropertyValueFactory<>("bodega"));
        producto_cl_cas.setCellValueFactory(new PropertyValueFactory<>("cas"));
        producto_cl_cod_interno.setCellValueFactory(new PropertyValueFactory<>("codigo_interno"));
        producto_cl_cod_stnd.setCellValueFactory(new PropertyValueFactory<>("codigo_standard"));
        producto_cl_lote.setCellValueFactory(new PropertyValueFactory<>("lote"));
        producto_cl_fingreso.setCellValueFactory(new PropertyValueFactory<>("fecha_de_ingreso"));
        producto_cl_fvencimiento.setCellValueFactory(new PropertyValueFactory<>("fecha_de_vencimiento"));
        producto_cl_fabierto.setCellValueFactory(new PropertyValueFactory<>("fecha_abierto"));
        producto_cl_presentacion.setCellValueFactory(new PropertyValueFactory<>("presentacion"));
        producto_cl_stock.setCellValueFactory(new PropertyValueFactory<>("stock"));
        producto_cl_costo.setCellValueFactory(new PropertyValueFactory<>("costo"));
        producto_cl_proveedor.setCellValueFactory(new PropertyValueFactory<>("proveedor"));
    }

    public String datosIntroducidos(){
        String sqlQuery = "SELECT id, nombre, marca, bodega, cas, codigo_interno, codigo_standard, lote, fecha_ingreso, fecha_vence, fecha_abierto," +
                " presentacion, stock, costo, proveedor_nombre FROM productos WHERE ";

        if(!buscar_producto_txtfl_nombre.getText().isEmpty()){
            sqlQuery += "nombre LIKE '%"+buscar_producto_txtfl_nombre.getText()+"%' AND";
        }

        if(!buscar_producto_txtfl_marca.getText().isEmpty()){
            sqlQuery += "marca LIKE '%"+buscar_producto_txtfl_marca.getText()+"%' AND";
        }

        if (!buscar_producto_txtfl_lote.getText().isEmpty()){
            sqlQuery += "lote LIKE '%"+buscar_producto_txtfl_lote.getText()+"%' AND";
        }

        if (!buscar_producto_txtfl_factura.getText().isEmpty()){
            sqlQuery += "factura LIKE '%"+buscar_producto_txtfl_factura.getText()+"%' AND";
        }

        if (!buscar_producto_txtfl_cas.getText().isEmpty()){
            sqlQuery += "cas LIKE '%"+buscar_producto_txtfl_cas.getText()+"%' AND";
        }

        if (!buscar_producto_txtfl_codinterno.getText().isEmpty()){
            sqlQuery += "codigo_interno LIKE '%"+buscar_producto_txtfl_codinterno.getText()+"%' AND";
        }

        if (!buscar_producto_txtfl_codstandard.getText().isEmpty()){
            sqlQuery += "codigo_standard LIKE '%"+buscar_producto_txtfl_codstandard.getText()+"%' AND";
        }

        if (!(buscar_producto_cmbox_prov.getValue() == null)){
            sqlQuery += "proveedor_nombre LIKE '%"+buscar_producto_cmbox_prov.getValue().toString()+"%' AND";
        }

        if(!(buscar_producto_cmbox_bodega.getValue() == null)){
            sqlQuery += "bodega LIKE '%"+buscar_producto_cmbox_bodega.getValue().toString()+"%' AND";
        }

        if(!(buscar_producto_dtpcker_ingreso.getValue() == null)){
            sqlQuery += "fecha_ingreso="+ Date.valueOf(buscar_producto_dtpcker_ingreso.getValue())+" AND";
        }

        if(!(buscar_producto_dtpcker_vence.getValue() == null)){
            sqlQuery += "fecha_vence="+ Date.valueOf(buscar_producto_dtpcker_vence.getValue())+" AND";
        }

        char[] stringToArray = sqlQuery.toCharArray();
        String limpiarDatos = "";

        for(int i = 0;i < stringToArray.length-4; i ++){
            limpiarDatos = limpiarDatos + stringToArray[i];
        }

        sqlQuery = limpiarDatos;
        return sqlQuery;
    }


}
