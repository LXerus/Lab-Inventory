package Controladores.Productos;

import Controladores.MenuPrincipal.MenuPrincipal_Controlador;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MenuProductos_Controlador implements Initializable {
    private AnchorPane panel_seleccionado;
    private FXMLLoader fxmlLoader;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void irRegistrarProducto() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Formularios/registrar_producto_gui.fxml"));
        panel_seleccionado = fxmlLoader.load();
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_seleccionado);

    }

    public void irBuscarProductos() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Formularios/buscar_producto_gui.fxml"));
        panel_seleccionado = fxmlLoader.load();
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_seleccionado);
    }
}
