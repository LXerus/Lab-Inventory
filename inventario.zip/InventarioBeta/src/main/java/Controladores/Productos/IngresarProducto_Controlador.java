package Controladores.Productos;

import Clases.Cruds.Productos_Crud;
import Clases.Modelos.Producto;
import Clases.Modelos.UsuarioActual;
import Controladores.MenuPrincipal.MenuPrincipal_Controlador;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

public class IngresarProducto_Controlador implements Initializable {
    private FXMLLoader fxmlLoader;
    private AnchorPane panel_menu_productos;
    private Productos_Crud productosCrud = new Productos_Crud();
    private ObservableList proveedores_nombres = FXCollections.observableArrayList();
    private ObservableList proveedores_codigos = FXCollections.observableArrayList();
    private Producto producto;

    private String nombre;
    private String marca;
    private String cas;
    private String codigo_interno;
    private String codigo_standard;
    private String lote;
    private String presentacion;
    private String numero_de_factura;
    private double costo;
    private int stock;
    private String tipo_de_producto;
    private String registro;
    private String bodega;
    private String proveedor;
    private String codigo_de_proveedor;
    private LocalDate fecha_de_factura;
    private LocalDate fecha_de_ingreso;
    private LocalDate fecha_de_vencimiento;
    private LocalDate fecha_abierto;
    private int idProveedor;
    private int idBodega;
    private int idUsuario;
    private LocalDate fechaDeHoy = LocalDate.now();

    @FXML
    private AnchorPane panel_ingresar_producto;

    //TextFields
    @FXML
    private TextField registrar_producto_txtfl_nombre;
    @FXML
    private TextField registrar_producto_txtfl_marca;
    @FXML
    private TextField registrar_producto_txtfl_cas;
    @FXML
    private TextField registrar_producto_txtfl_codigo_interno;
    @FXML
    private TextField registrar_producto_txtfl_codigo_standard;
    @FXML
    private TextField registrar_producto_txtfl_lote;
    @FXML
    private TextField registrar_producto_txtfl_stock;
    @FXML
    private TextField registrar_producto_txtfl_numero_factura;
    @FXML
    private TextField registrar_producto_txtfl_costo;
    @FXML
    private TextField registrar_producto_txtfl_codigoproveedor;

    //ComboBoxes
    @FXML
    private ComboBox registrar_producto_cmbox_presentacion;
    @FXML
    private ComboBox registrar_producto_cmbox_registro;
    @FXML
    private ComboBox registrar_producto_cmbox_tipo_producto;
    @FXML
    private ComboBox registrar_producto_cmbox_bodega;
    @FXML
    private ComboBox registrar_producto_cmbox_proveedor;

    //DatePickers
    @FXML
    private DatePicker registrar_producto_dtpicker_fecha_factura;
    @FXML
    private DatePicker registrar_producto_dtpicker_fecha_ingreso;
    @FXML
    private DatePicker registrar_producto_dtpicker_fecha_vencimiento;
    @FXML
    private DatePicker registrar_producto_dtpicker_fecha_abierto;

    public void initialize(URL url, ResourceBundle resourceBundle) {
        generarListas();
        registrar_producto_txtfl_codigoproveedor.setText(productosCrud.obtenerProveedores().get(0).getCodigoDeProveedor());
        registrar_producto_cmbox_presentacion.setItems(productosCrud.obtenerListaDePresentaciones());
        registrar_producto_cmbox_presentacion.setValue(productosCrud.obtenerListaDePresentaciones().get(0));
        registrar_producto_cmbox_bodega.setItems(productosCrud.obtenerListaDeBodegas());
        registrar_producto_cmbox_bodega.setValue(productosCrud.obtenerListaDeBodegas().get(0));
        registrar_producto_cmbox_tipo_producto.setItems(productosCrud.obtenerListaTipoDeProductos());
        registrar_producto_cmbox_tipo_producto.setValue(productosCrud.obtenerListaTipoDeProductos().get(0));
        registrar_producto_cmbox_registro.setItems(productosCrud.obtenerNumerosDeRegistro());
        registrar_producto_cmbox_registro.setValue(productosCrud.obtenerNumerosDeRegistro().get(0));
        registrar_producto_cmbox_proveedor.setItems(proveedores_nombres);
        registrar_producto_cmbox_proveedor.setValue(proveedores_nombres.get(0));

        registrar_producto_dtpicker_fecha_factura.setValue(fechaDeHoy);
        registrar_producto_dtpicker_fecha_ingreso.setValue(fechaDeHoy);
        registrar_producto_dtpicker_fecha_vencimiento.setValue(fechaDeHoy);
        registrar_producto_dtpicker_fecha_abierto.setValue(fechaDeHoy);

        registrar_producto_txtfl_codigoproveedor.setEditable(false);
        registrar_producto_cmbox_proveedor.valueProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object o, Object t1) {
                obtenerCodigoProveedores();
            }
        });
    }

    public void cancelar() throws IOException {
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Menus/menu_productos_gui.fxml"));
        panel_menu_productos = fxmlLoader.load();
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_menu_productos);
    }

    public void registrarProducto(){
        presentacion = registrar_producto_cmbox_presentacion.getValue().toString();
        registro = registrar_producto_cmbox_registro.getValue().toString();
        tipo_de_producto = registrar_producto_cmbox_tipo_producto.getValue().toString();
        bodega = registrar_producto_cmbox_bodega.getValue().toString();
        proveedor = registrar_producto_cmbox_proveedor.getValue().toString();
        codigo_de_proveedor = registrar_producto_txtfl_codigo_standard.getText();
        fecha_de_factura = registrar_producto_dtpicker_fecha_factura.getValue();
        fecha_de_ingreso = registrar_producto_dtpicker_fecha_ingreso.getValue();
        fecha_abierto = registrar_producto_dtpicker_fecha_abierto.getValue();
        fecha_de_vencimiento = registrar_producto_dtpicker_fecha_vencimiento.getValue();
        idUsuario = UsuarioActual.getUsuarioActual().getId();
        if(validarDatos()){
            Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
            confirmacion.setTitle("Registrar Producto");
            confirmacion.setHeaderText("Registrando un nuevo producto");
            confirmacion.setContentText("Esta a punto de registrar a un nuevo producto ¿desea continuar?");
            Optional<ButtonType> resultado = confirmacion.showAndWait();
            if(resultado.get() == ButtonType.OK) {
                producto = new Producto(nombre, marca, cas, codigo_interno,codigo_standard, lote,
                        presentacion, numero_de_factura, costo, stock, tipo_de_producto,registro,
                        bodega, proveedor, codigo_de_proveedor, fecha_de_factura,fecha_de_ingreso,fecha_de_vencimiento,fecha_abierto, idProveedor, idUsuario);
                productosCrud.registrarProducto(producto);
                JOptionPane.showMessageDialog(null,"¡El usuario se ha registrado exitosamente!");

                try {
                    fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Menus/menu_productos_gui.fxml"));
                    panel_menu_productos = fxmlLoader.load();
                    MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_menu_productos);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                 }else{
                JOptionPane.showMessageDialog(null, "No se han efectuado cambios en la base de datos.");
                 }
        }else{
            JOptionPane.showMessageDialog(null,"Por favor ingresar la informacion en todos los campos.");
        }
    }



    public void obtenerCodigoProveedores(){
        String proveedor = registrar_producto_cmbox_proveedor.getValue().toString();
        for(int i = 0; i < productosCrud.obtenerProveedores().size(); i++){
            if(proveedor.contains(productosCrud.obtenerProveedores().get(i).getNombre())){
                registrar_producto_txtfl_codigoproveedor.setText(productosCrud.obtenerProveedores().get(i).getCodigoDeProveedor());
                idProveedor = productosCrud.obtenerProveedores().get(i).getId();
            }
        }
    }

    public void generarListas(){
        for(int i = 0;i < productosCrud.obtenerProveedores().size(); i++){
            proveedores_nombres.add(productosCrud.obtenerProveedores().get(i).getNombre());
            proveedores_codigos.add(productosCrud.obtenerProveedores().get(i).getCodigoDeProveedor());
        }
    }

    public boolean validarDatos(){
        boolean datosValidos = true;

        if(registrar_producto_txtfl_nombre.getText().isEmpty()){
            datosValidos = false;
        }else{
            nombre = registrar_producto_txtfl_nombre.getText();
        }

        if(registrar_producto_txtfl_marca.getText().isEmpty()){
            datosValidos = false;
        }else{
            marca = registrar_producto_txtfl_marca.getText();
        }

        if(registrar_producto_txtfl_cas.getText().isEmpty()){
            datosValidos = false;
        }else{
            cas = registrar_producto_txtfl_cas.getText();
        }

        if(registrar_producto_txtfl_codigo_interno.getText().isEmpty()){
            datosValidos = false;
        }else {
            codigo_interno = registrar_producto_txtfl_codigo_interno.getText();
        }

        if(registrar_producto_txtfl_codigo_standard.getText().isEmpty()){
            datosValidos = false;
        }else {
            codigo_standard = registrar_producto_txtfl_codigo_standard.getText();
        }

        if(registrar_producto_txtfl_lote.getText().isEmpty()){
            datosValidos = false;
        }else {
            lote = registrar_producto_txtfl_lote.getText();
        }

        if(registrar_producto_txtfl_stock.getText().isEmpty()){
            datosValidos = false;
        }else {
            stock = Integer.parseInt(registrar_producto_txtfl_stock.getText());
        }

        if(registrar_producto_txtfl_numero_factura.getText().isEmpty()){
            datosValidos = false;
        }else {
            numero_de_factura =  registrar_producto_txtfl_numero_factura.getText();
        }

        if(registrar_producto_txtfl_costo.getText().isEmpty()){
            datosValidos = false;
        }else {
             costo = Double.parseDouble(registrar_producto_txtfl_costo.getText());
        }

        return datosValidos;
    }
}