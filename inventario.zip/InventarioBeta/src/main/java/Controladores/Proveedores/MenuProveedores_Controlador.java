package Controladores.Proveedores;

import Controladores.MenuPrincipal.MenuPrincipal_Controlador;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MenuProveedores_Controlador implements Initializable {
   @FXML
   AnchorPane panel_menu_proveedores;

   private FXMLLoader fxmlLoader;

   private AnchorPane panel_registrar_proveedor;
   private AnchorPane panel_buscar_proveeodr;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void irRegistrarProveedor(){
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Formularios/registrar_proveedor_gui.fxml"));
        try {
            panel_registrar_proveedor = fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_registrar_proveedor);
    }

    public void irBuscarProveedor(){
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Formularios/buscar_proveedor_gui.fxml"));
        try {
            panel_buscar_proveeodr = fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_buscar_proveeodr);
    }
}
