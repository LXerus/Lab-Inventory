package Controladores.Usuarios;

import Clases.Conexion;
import Clases.Modelos.Usuario;
import Clases.Modelos.UsuarioActual;
import Controladores.MenuPrincipal.MenuPrincipal_Controlador;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ResourceBundle;

public class Login_Controller implements Initializable {
    Stage loginStage;
    MenuPrincipal_Controlador menuPrincipalControlador = new MenuPrincipal_Controlador();

    @FXML
    AnchorPane panel_login;
    @FXML
    Label login_texto_loginfail;
    @FXML
    TextField login_txtfl_id;
    @FXML
    PasswordField login_pswfl_password;
    @FXML
    Button login_btn_cancelar;
    @FXML
    Button login_btn_login;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public Stage crearPanelLogin(Stage stage) throws IOException {
        panel_login = FXMLLoader.load(getClass().getResource("/gui/Menus/login_gui.fxml"));
        stage.setTitle("LogIn");
        stage.setScene(new Scene(panel_login, 600, 400));
        stage.show();
        return stage;
    }

    public void loginCheck(){
        LocalDate fechaDeEntrada;
        LocalTime horaDeEntrada;
        Usuario usuario;

        if(validarDatos()){
            int id = Integer.parseInt(login_txtfl_id.getText());
            String password = login_pswfl_password.getText();
            Conexion conexion = new Conexion();
            Connection sqlConnection  = conexion.getConnection();
            String sqlQuery = "SELECT id, nombres, apellidos, password, fecha_de_ingreso, area, activo, correo_electronico, privilegios FROM usuario WHERE id='"+id+"' AND password='"+password+"'";
            ResultSet usuarioResultSet = null;

            try {
                Statement buscarUsuarioStatement = sqlConnection.createStatement();
                usuarioResultSet = buscarUsuarioStatement.executeQuery(sqlQuery);
                if(usuarioResultSet.next() == false){
                    login_texto_loginfail.setText("El ID de usuario o contraseña son invalidos");
                    usuarioResultSet.beforeFirst();
                }else{
                    int id_usuario = usuarioResultSet.getInt(1);
                    String nombre_usuario = usuarioResultSet.getString(2);
                    String apellidos_usuario = usuarioResultSet.getString(3);
                    String password_usuario = usuarioResultSet.getString(4);
                    Date fdi_usuario = usuarioResultSet.getDate(5);
                    String area_usuario = usuarioResultSet.getString(6);
                    boolean activo_usuario = usuarioResultSet.getBoolean(7);
                    String correo_electronico_usuario = usuarioResultSet.getString(8);
                    String privilegios_usuario = usuarioResultSet.getString( 9);

                    fechaDeEntrada = LocalDate.now();
                    horaDeEntrada = LocalTime.now();
                    usuario = new Usuario(id, nombre_usuario, apellidos_usuario, password_usuario, fdi_usuario.toLocalDate(), area_usuario, activo_usuario, correo_electronico_usuario, privilegios_usuario);
                    UsuarioActual.obtenerDatosDeUsuario(usuario, fechaDeEntrada, horaDeEntrada);
                    usuarioResultSet.beforeFirst();

                    loginStage = (Stage) login_btn_login.getScene().getWindow();
                    menuPrincipalControlador.crearMenuPrincipal(loginStage);

                }

            } catch (SQLException | IOException e) {
                e.printStackTrace();
            }

        }else{
            JOptionPane.showMessageDialog(null, "Debe ingresar su ID y contraseña.");
        }
    }

    public void cancelar(){
        Stage stage = (Stage) login_btn_cancelar.getScene().getWindow();
        stage.close();
    }

    public boolean validarDatos(){
        boolean datosEstado = true;
        if(login_txtfl_id.getText().isEmpty()){
            datosEstado = false;
        }
        if(login_pswfl_password.getText().isEmpty()){
            datosEstado = false;
        }
        return datosEstado;
    }
}
