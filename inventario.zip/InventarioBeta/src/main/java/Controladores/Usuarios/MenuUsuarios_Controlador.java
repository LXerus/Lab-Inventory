package Controladores.Usuarios;

import Controladores.MenuPrincipal.MenuPrincipal_Controlador;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MenuUsuarios_Controlador implements Initializable {
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    @FXML
    private AnchorPane panel_menu_usuarios;
    @FXML
    private Button menu_usuarios_btn_insertar;
    @FXML
    private Button menu_usuarios_btn_buscar;
    @FXML
    private Button menu_usuarios_btn_desactivar;
    @FXML
    private Button menu_usuarios_btn_activar;

    FXMLLoader fxmlLoader;
    AnchorPane panel_seleccionado;

    public void irRegistrarUsuario(){
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Formularios/registrar_usuario_gui.fxml"));
        try {
            panel_seleccionado = fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_seleccionado);
    }

    public void irBuscarUsuario(){
        fxmlLoader = new FXMLLoader(getClass().getResource("/gui/Formularios/buscar_usuarios_gui.fxml"));
        try {
            panel_seleccionado = fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        MenuPrincipal_Controlador.obntenerPanelPadre().setCenter(panel_seleccionado);
    }
}
