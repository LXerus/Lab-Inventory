package Clases.Modelos;

import java.time.LocalDate;

public class Producto {
    private int id;
    private String nombre;
    private String marca;
    private String cas;
    private String codigo_interno;
    private String codigo_standard;
    private String lote;
    private String presentacion;
    private String numero_de_factura;
    private double costo;
    private int stock;
    private String bodega;
    private String tipo_de_producto;
    private String registro;
    private String proveedor;
    private String codigo_de_proveedor;
    private LocalDate fecha_de_factura;
    private LocalDate fecha_de_ingreso;
    private LocalDate fecha_de_vencimiento;
    private LocalDate fecha_abierto;
    private int idProveedor;
    private int idBodega;
    private int idUsuario;

    public Producto(int id, String nombre, String marca, String cas, String codigo_interno, String codigo_standard, String lote, String presentacion, String numero_de_factura, double costo, int stock, String tipo_de_producto, String registro, String bodega, String proveedor, String codigo_de_proveedor, LocalDate fecha_de_factura, LocalDate fecha_de_ingreso, LocalDate fecha_de_vencimiento, LocalDate fecha_abierto, int idProveedor, int idBodega, int idUsuario) {
        this.id = id;
        this.nombre = nombre;
        this.marca = marca;
        this.cas = cas;
        this.codigo_interno = codigo_interno;
        this.codigo_standard = codigo_standard;
        this.lote = lote;
        this.presentacion = presentacion;
        this.numero_de_factura = numero_de_factura;
        this.costo = costo;
        this.stock = stock;
        this.tipo_de_producto = tipo_de_producto;
        this.registro = registro;
        this.bodega = bodega;
        this.proveedor = proveedor;
        this.codigo_de_proveedor = codigo_de_proveedor;
        this.fecha_de_factura = fecha_de_factura;
        this.fecha_de_ingreso = fecha_de_ingreso;
        this.fecha_de_vencimiento = fecha_de_vencimiento;
        this.fecha_abierto = fecha_abierto;
        this.idProveedor = idProveedor;
        this.idBodega = idBodega;
        this.idUsuario = idUsuario;
    }

    public Producto(int id, String nombre, String marca, String bodega, String cas, String codigo_interno, String codigo_standard, String lote, LocalDate fecha_de_ingreso, LocalDate fecha_de_vencimiento, LocalDate fecha_abiertoString, String presentacion, double costo, int stock, String proveedor) {
        this.id = id;
        this.nombre = nombre;
        this.marca = marca;
        this.cas = cas;
        this.codigo_interno = codigo_interno;
        this.codigo_standard = codigo_standard;
        this.lote = lote;
        this.presentacion = presentacion;
        this.costo = costo;
        this.stock = stock;
        this.bodega = bodega;
        this.proveedor = proveedor;
        this.fecha_de_ingreso = fecha_de_ingreso;
        this.fecha_de_vencimiento = fecha_de_vencimiento;
        this.fecha_abierto = fecha_abierto;
    }

    public Producto(String nombre, String marca, String cas, String codigo_interno, String codigo_standard, String lote, String presentacion, String numero_de_factura, double costo, int stock, String tipo_de_producto, String registro, String bodega, String proveedor, String codigo_de_proveedor, LocalDate fecha_de_factura, LocalDate fecha_de_ingreso, LocalDate fecha_de_vencimiento, LocalDate fecha_abierto, int idProveedor, int idUsuario) {
        this.nombre = nombre;
        this.marca = marca;
        this.cas = cas;
        this.codigo_interno = codigo_interno;
        this.codigo_standard = codigo_standard;
        this.lote = lote;
        this.presentacion = presentacion;
        this.numero_de_factura = numero_de_factura;
        this.costo = costo;
        this.stock = stock;
        this.tipo_de_producto = tipo_de_producto;
        this.registro = registro;
        this.bodega = bodega;
        this.proveedor = proveedor;
        this.codigo_de_proveedor = codigo_de_proveedor;
        this.fecha_de_factura = fecha_de_factura;
        this.fecha_de_ingreso = fecha_de_ingreso;
        this.fecha_de_vencimiento = fecha_de_vencimiento;
        this.fecha_abierto = fecha_abierto;
        this.idProveedor = idProveedor;
        this.idUsuario = idUsuario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCas() {
        return cas;
    }

    public void setCas(String cas) {
        this.cas = cas;
    }

    public String getCodigo_interno() {
        return codigo_interno;
    }

    public void setCodigo_interno(String codigo_interno) {
        this.codigo_interno = codigo_interno;
    }

    public String getCodigo_standard() {
        return codigo_standard;
    }

    public void setCodigo_standard(String codigo_standard) {
        this.codigo_standard = codigo_standard;
    }

    public String getLote() {
        return lote;
    }

    public void setLote(String lote) {
        this.lote = lote;
    }

    public String getPresentacion() {
        return presentacion;
    }

    public void setPresentacion(String presentacion) {
        this.presentacion = presentacion;
    }

    public String getNumero_de_factura() {
        return numero_de_factura;
    }

    public void setNumero_de_factura(String numero_de_factura) {
        this.numero_de_factura = numero_de_factura;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getTipo_de_producto() {
        return tipo_de_producto;
    }

    public void setTipo_de_producto(String tipo_de_producto) {
        this.tipo_de_producto = tipo_de_producto;
    }

    public String getRegistro() {
        return registro;
    }

    public void setRegistro(String registro) {
        this.registro = registro;
    }

    public String getBodega() {
        return bodega;
    }

    public void setBodega(String bodega) {
        this.bodega = bodega;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public String getCodigo_de_proveedor() {
        return codigo_de_proveedor;
    }

    public void setCodigo_de_proveedor(String codigo_de_proveedor) {
        this.codigo_de_proveedor = codigo_de_proveedor;
    }

    public LocalDate getFecha_de_factura() {
        return fecha_de_factura;
    }

    public void setFecha_de_factura(LocalDate fecha_de_factura) {
        this.fecha_de_factura = fecha_de_factura;
    }

    public LocalDate getFecha_de_ingreso() {
        return fecha_de_ingreso;
    }

    public void setFecha_de_ingreso(LocalDate fecha_de_ingreso) {
        this.fecha_de_ingreso = fecha_de_ingreso;
    }

    public LocalDate getFecha_de_vencimiento() {
        return fecha_de_vencimiento;
    }

    public void setFecha_de_vencimiento(LocalDate fecha_de_vencimiento) {
        this.fecha_de_vencimiento = fecha_de_vencimiento;
    }

    public LocalDate getFecha_abierto() {
        return fecha_abierto;
    }

    public void setFecha_abierto(LocalDate fecha_abierto) {
        this.fecha_abierto = fecha_abierto;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public int getIdBodega() {
        return idBodega;
    }

    public void setIdBodega(int idBodega) {
        this.idBodega = idBodega;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
}


