package Clases.Cruds;

import Clases.Conexion;
import Clases.Modelos.Bodega;
import Clases.Modelos.UsuarioActividad;
import Clases.Modelos.UsuarioActual;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class Bodegas_Crud {
    private Connection jdbConection;
    private Conexion conexion;
    private ObservableList<Bodega> listaDeBodegas;
    private PreparedStatement preparedStatementBodegas;
    UsuarioActividad actividad;
    LocalDate fecha;
    LocalTime hora;
    LogActivades_Crud log;



    public void nuevaBodega(Bodega bodega){
        String nombre = bodega.getNombre();
        String condicion = bodega.getCondicion();
        String region = bodega.getRegion();
        String tramo = bodega.getTramo();
        conexion = new Conexion();
        Statement statement = null;

        try {
            jdbConection = conexion.getConnection();
            statement = jdbConection.createStatement();
            String sqlInstruction = "INSERT INTO bodega(bodega, condicion, region, tramo) VALUES('" + nombre + "', '" + condicion + "', '" + region + "', '" + tramo + "')";
            statement.executeUpdate(sqlInstruction);

            log = new LogActivades_Crud();
            fecha = LocalDate.now();
            hora = LocalTime.now();
            actividad = new UsuarioActividad(
                    UsuarioActual.getUsuarioActual().getId(),
                    UsuarioActual.getUsuarioActual().getNombres(),
                    UsuarioActual.getUsuarioActual().getApellidos(),
                    UsuarioActual.getUsuarioActual().getCorreo_electronico(),
                    "Registro de Bodega",
                    "Bodegas",
                    fecha,
                    hora
            );
            log.registrarActividad(actividad);

        }catch (SQLException e){
            e.printStackTrace();
        }finally{
            statement = null;
            jdbConection = null;
            conexion.desconectar();
        }
    }

 public ObservableList<Bodega> buscarBodega(String query) {
        ResultSet resultSetConsultarBodegas = null;
        listaDeBodegas = FXCollections.observableArrayList();
        conexion = new Conexion();
        jdbConection = conexion.getConnection();
        try {
            Statement consultarBase = jdbConection.createStatement();
            resultSetConsultarBodegas = consultarBase.executeQuery(query);

            while (resultSetConsultarBodegas.next()) {
                int id_bodega = resultSetConsultarBodegas.getInt(1);
                String nombre_bodega = resultSetConsultarBodegas.getString(2);
                String condicion_bodega = resultSetConsultarBodegas.getString(3);
                String region_bodega = resultSetConsultarBodegas.getString(4);
                String tramo_bodega = resultSetConsultarBodegas.getString(5);
                listaDeBodegas.add(new Bodega(id_bodega, nombre_bodega, condicion_bodega, region_bodega, tramo_bodega));
            }
            log = new LogActivades_Crud();
            fecha = LocalDate.now();
            hora = LocalTime.now();
            actividad = new UsuarioActividad(
                    UsuarioActual.getUsuarioActual().getId(),
                    UsuarioActual.getUsuarioActual().getNombres(),
                    UsuarioActual.getUsuarioActual().getApellidos(),
                    UsuarioActual.getUsuarioActual().getCorreo_electronico(),
                    "Busqueda de Bodega",
                    "Bodegas",
                    fecha,
                    hora
            );
            log.registrarActividad(actividad);
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            resultSetConsultarBodegas = null;
            jdbConection = null;
            conexion.desconectar();
        }
     return listaDeBodegas;
    }


}
