package Clases.Cruds;

import Clases.Conexion;
import Clases.Modelos.Proveedor;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;

public class Proveedores_Crud {
    private Connection jdbConection;
    private Conexion conexion;
    private ObservableList<Proveedor> listaDeProveedores;

    public Proveedores_Crud(){}

    public void nuevoProveedor(Proveedor proveedor){
        String nombre = proveedor.getNombre();
        String telefono = proveedor.getTelefono();
        String contacto = proveedor.getContacto();
        String codigo = proveedor.getCodigoDeProveedor();
        String servicios = proveedor.getServicio();
        double punteo = proveedor.getPunteo();
        boolean critico = proveedor.isCritico();
        boolean aprovado = proveedor.isAprobado();
        LocalDate fecha_de_aprovacion = proveedor.getFechaDeAprobacion();
        LocalDate fecha_de_revalidacion = proveedor.getFechaDeRevalidacion();

        conexion = new Conexion();
        PreparedStatement preparedStatement = null;
        String instruccionSQL = "INSERT INTO proveedores (nombre, telefono, contacto, codigo_de_proveedor servicio, critico, aprobado, punteo, fecha_aprobacion, fecha_revalidacion) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try{
            jdbConection = conexion.getConnection();
            preparedStatement = jdbConection.prepareStatement(instruccionSQL);
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, telefono);
            preparedStatement.setString(3, contacto);
            preparedStatement.setString(4,codigo);
            preparedStatement.setString(5, servicios);
            preparedStatement.setDouble(6, punteo);
            preparedStatement.setBoolean(7, critico);
            preparedStatement.setBoolean(8, aprovado);
            preparedStatement.setDate(9, Date.valueOf(fecha_de_aprovacion));
            preparedStatement.setDate(10, Date.valueOf(fecha_de_revalidacion));
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            preparedStatement = null;
            jdbConection = null;
         }
    }

    public ObservableList<Proveedor> buscarProveedor(String query) {
        ResultSet resultSetConsultarProveedores = null;
        listaDeProveedores = FXCollections.observableArrayList();

        //Iniciando la conexion con la base de datos
       try {
           conexion = new Conexion();
           jdbConection = conexion.getConnection();
           Statement consultarBase = jdbConection.createStatement();
           resultSetConsultarProveedores = consultarBase.executeQuery(query);

           while (resultSetConsultarProveedores.next()) {
               int id_proveedor = resultSetConsultarProveedores.getInt(1);
               String nombre_proveedor = resultSetConsultarProveedores.getString(2);
               String telefono_proveedor = resultSetConsultarProveedores.getString(3);
               String contacto_proveedor = resultSetConsultarProveedores.getString(4);
            /*   String codigo_proveedor = resultSetConsultarProveedores.getString(5);
               String servicio_proveedor = resultSetConsultarProveedores.getString(6);
               int puntaje_proveedor = resultSetConsultarProveedores.getInt(7);
               boolean critico_proveedor = resultSetConsultarProveedores.getBoolean(8);
               boolean aprobado_proveedor = resultSetConsultarProveedores.getBoolean(9);
               Date fecha_aprobacion_proveedor = resultSetConsultarProveedores.getDate(10);
               Date fecha_revalidacion_proveedor = resultSetConsultarProveedores.getDate(11);*/

               listaDeProveedores.add(new Proveedor(id_proveedor, nombre_proveedor, telefono_proveedor, contacto_proveedor));
           }
       }catch (SQLException e){
           e.printStackTrace();
       }
        jdbConection = null;
        conexion.desconectar();
        return listaDeProveedores;
    }
}
