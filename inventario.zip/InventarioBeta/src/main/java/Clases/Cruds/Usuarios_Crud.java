package Clases.Cruds;

import Clases.Conexion;
import Clases.Modelos.Usuario;
import Clases.Modelos.UsuarioActividad;
import Clases.Modelos.UsuarioActual;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class Usuarios_Crud {
    Conexion conexion;
    Connection sqlConnection;
    PreparedStatement usuarioStatement;
    UsuarioActividad actividad;
    LocalDate fecha;
    LocalTime hora;
    LogActivades_Crud log;


    public void registrarUsuario(Usuario usuario){
        conexion = new Conexion();
        sqlConnection = conexion.getConnection();
        String instruccionSQL = "INSERT INTO usuario (nombres, apellidos, password, fecha_de_ingreso, area, activo, correo_electronico, privilegios) "+
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            usuarioStatement = sqlConnection.prepareStatement(instruccionSQL);
            usuarioStatement.setString(1, usuario.getNombres());
            usuarioStatement.setString(2, usuario.getApellidos());
            usuarioStatement.setString(3, usuario.getPassword());
            usuarioStatement.setDate(4, Date.valueOf(usuario.getFecha_de_ingreso()));
            usuarioStatement.setString(5, usuario.getArea());
            usuarioStatement.setBoolean(6, usuario.isActivo());
            usuarioStatement.setString(7, usuario.getCorreo_electronico());
            usuarioStatement.setString(8, usuario.getPrivilegios());
            usuarioStatement.executeUpdate();

            log = new LogActivades_Crud();
            fecha = LocalDate.now();
            hora = LocalTime.now();
            actividad = new UsuarioActividad(
                    UsuarioActual.getUsuarioActual().getId(),
                    UsuarioActual.getUsuarioActual().getNombres(),
                    UsuarioActual.getUsuarioActual().getApellidos(),
                    UsuarioActual.getUsuarioActual().getCorreo_electronico(),
                    "Registro de nuevo usuario",
                    "Usuario",
                    fecha,
                    hora
            );
            log.registrarActividad(actividad);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            usuarioStatement = null;
            sqlConnection = null;
            conexion.desconectar();
        }
    }

    public ObservableList<Usuario> buscarUsuario(String consultaSQL){
        ObservableList<Usuario> listaDeUsuarios = FXCollections.observableArrayList();
        conexion = new Conexion();
        sqlConnection  = conexion.getConnection();
        Statement usuarioStatement;
        ResultSet usuarioResultset;
        try{
            usuarioStatement = sqlConnection.createStatement();
            usuarioResultset = usuarioStatement.executeQuery(consultaSQL);
            while(usuarioResultset.next()){
                int id = usuarioResultset.getInt(1);
                String nombres = usuarioResultset.getString(2);
                String apellidos = usuarioResultset.getString(3);
                LocalDate fechaDeIngreso = usuarioResultset.getDate(4).toLocalDate();
                String area = usuarioResultset.getString(5);
                Boolean activo = usuarioResultset.getBoolean(6);
                String email = usuarioResultset.getString(7);
                String privilegios = usuarioResultset.getString(8);

                String estado = "";
                if(activo){
                    estado = "Activo";
                }else {
                    estado = "Inactivo";
                }
                listaDeUsuarios.add(new Usuario(id, nombres, apellidos, fechaDeIngreso, area, estado, email, privilegios));
            }
            log = new LogActivades_Crud();
            fecha = LocalDate.now();
            hora = LocalTime.now();
            actividad = new UsuarioActividad(
                    UsuarioActual.getUsuarioActual().getId(),
                    UsuarioActual.getUsuarioActual().getNombres(),
                    UsuarioActual.getUsuarioActual().getApellidos(),
                    UsuarioActual.getUsuarioActual().getCorreo_electronico(),
                    "Busqueda de Usuario",
                    "Usuario",
                    fecha,
                    hora
            );
            log.registrarActividad(actividad);
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            usuarioStatement = null;
            sqlConnection = null;
            conexion.desconectar();
        }
        return listaDeUsuarios;
    }
}
