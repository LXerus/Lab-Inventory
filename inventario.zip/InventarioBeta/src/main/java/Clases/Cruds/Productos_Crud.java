package Clases.Cruds;
import Clases.Conexion;
import Clases.Modelos.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class Productos_Crud {
    Conexion conexion;
    Connection sqlConexion;
    private ObservableList<Bodega> listaDeProductos;
    private PreparedStatement preparedStatementProductos;
    UsuarioActividad actividad;
    LocalDate fecha;
    LocalTime hora;
    LogActivades_Crud log;

    public void registrarProducto(Producto producto){
        conexion = new Conexion();
        sqlConexion = conexion.getConnection();
        String sqlInstruction = "INSERT INTO productos(nombre, marca, cas, codigo_interno, codigo_standard, lote, fecha_ingreso, fecha_vence," +
                " fecha_abierto, presentacion, stock, bodega, factura, costo, proveedor_nombre, proveedor_codigo) " +
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            preparedStatementProductos = sqlConexion.prepareStatement(sqlInstruction);
            preparedStatementProductos.setString(1, producto.getNombre());
            preparedStatementProductos.setString(2, producto.getMarca());
            preparedStatementProductos.setString(3, producto.getCas());
            preparedStatementProductos.setString(4, producto.getCodigo_interno());
            preparedStatementProductos.setString(5, producto.getCodigo_standard());
            preparedStatementProductos.setString(6, producto.getLote());
            preparedStatementProductos.setDate(7, Date.valueOf(producto.getFecha_de_ingreso()));
            preparedStatementProductos.setDate(8, Date.valueOf(producto.getFecha_de_vencimiento()));
            preparedStatementProductos.setDate(9, Date.valueOf(producto.getFecha_abierto()));
            preparedStatementProductos.setString(10,producto.getPresentacion());
            preparedStatementProductos.setInt(11, producto.getStock());
            preparedStatementProductos.setString(12, producto.getBodega());
            preparedStatementProductos.setString(13, producto.getNumero_de_factura());
            preparedStatementProductos.setDouble(14, producto.getCosto());
            preparedStatementProductos.setString(15, producto.getProveedor());
            preparedStatementProductos.setString(16, producto.getCodigo_de_proveedor());
        /*    preparedStatementProductos.setInt(17, producto.getIdBodega());
            preparedStatementProductos.setInt(18, producto.getIdUsuario());*/
            preparedStatementProductos.executeUpdate();

            log = new LogActivades_Crud();
            fecha = LocalDate.now();
            hora = LocalTime.now();
            actividad = new UsuarioActividad(
                    UsuarioActual.getUsuarioActual().getId(),
                    UsuarioActual.getUsuarioActual().getNombres(),
                    UsuarioActual.getUsuarioActual().getApellidos(),
                    UsuarioActual.getUsuarioActual().getCorreo_electronico(),
                    "Registro de producto",
                    "Productos",
                    fecha,
                    hora
            );
            log.registrarActividad(actividad);

        }catch (SQLException e){
            e.printStackTrace();
        }finally{
            preparedStatementProductos = null;
            sqlConexion = null;
            conexion.desconectar();
        }
    }

    public ObservableList<Producto> buscarProductos(String query){
        ObservableList<Producto> listaDeProductos = FXCollections.observableArrayList();
        conexion = new Conexion();
        sqlConexion = conexion.getConnection();
        try{
            Statement productoStatement = sqlConexion.createStatement();
            ResultSet productoResultSet = productoStatement.executeQuery(query);
            while(productoResultSet.next()){
                int id = productoResultSet.getInt(1);
                String nombre = productoResultSet.getString(2);
                String marca = productoResultSet.getString(3);
                String bodega = productoResultSet.getString(4);
                String cas = productoResultSet.getString(5);
                String codigoInterno = productoResultSet.getString(6);
                String codigoStandard = productoResultSet.getString(7);
                String lote = productoResultSet.getString(8);
                LocalDate fechaIngreso = productoResultSet.getDate(9).toLocalDate();
                LocalDate fechaVencimiento = productoResultSet.getDate(10).toLocalDate();
                LocalDate fechaAbierto = productoResultSet.getDate(11).toLocalDate();
                String presentacion = productoResultSet.getString(12);
                int stock = productoResultSet.getInt(13);
                double costo = productoResultSet.getDouble(14);
                String proveedor = productoResultSet.getString(15);
                listaDeProductos.add(new Producto(
                   id, nombre, marca, bodega, cas, codigoInterno, codigoStandard, lote, fechaIngreso, fechaVencimiento, fechaAbierto,
                   presentacion, costo, stock, proveedor));
            }

            log = new LogActivades_Crud();
            fecha = LocalDate.now();
            hora = LocalTime.now();
            actividad = new UsuarioActividad(
                    UsuarioActual.getUsuarioActual().getId(),
                    UsuarioActual.getUsuarioActual().getNombres(),
                    UsuarioActual.getUsuarioActual().getApellidos(),
                    UsuarioActual.getUsuarioActual().getCorreo_electronico(),
                    "Busqueda de producto",
                    "Productos",
                    fecha,
                    hora
            );
            log.registrarActividad(actividad);
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            sqlConexion = null;
            conexion.desconectar();
        }
        return listaDeProductos;
    }

    public ObservableList<String> obtenerListaDePresentaciones(){
        ObservableList<String> listaDePresentaciones = FXCollections.observableArrayList();
        String consultaSQL = "SELECT id, presentacion, unidad_medida FROM presentaciones";
        conexion = new Conexion();
        sqlConexion = conexion.getConnection();
        try {
            Statement presentacionStatement = sqlConexion.createStatement();
            ResultSet presentacionResultSet = presentacionStatement.executeQuery(consultaSQL);
            while(presentacionResultSet.next()){
                int id = presentacionResultSet.getInt(1);
                String presentacion = presentacionResultSet.getString(2);
                String unidad_de_medida = presentacionResultSet.getString(3);
                String celda = unidad_de_medida+"  |  "+presentacion;
                listaDePresentaciones.add(celda);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            sqlConexion = null;
            conexion.desconectar();
        }
        return listaDePresentaciones;
    }

    public ObservableList<String> obtenerListaDeBodegas(){
        ObservableList<String> listaDeBodegas = FXCollections.observableArrayList();
        String consultaSQL = "SELECT nombre, condicion, region, tramo FROM bodega";
        conexion = new Conexion();
        sqlConexion = conexion.getConnection();
        try {
            Statement bodegasStatement = sqlConexion.createStatement();
            ResultSet bodegasResultSet = bodegasStatement.executeQuery(consultaSQL);
            while(bodegasResultSet.next()){
                String nombre = bodegasResultSet.getString(1);
                String condicion = bodegasResultSet.getString(2);
                String region = bodegasResultSet.getString(3);
                String tramo = bodegasResultSet.getString(4);
                String celda = nombre+"  |  "+condicion+"  |  "+region+"  |  "+tramo;
                listaDeBodegas.add(celda);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            sqlConexion = null;
            conexion.desconectar();
        }
        return listaDeBodegas;
    }

    public ObservableList<String> obtenerListaTipoDeProductos(){
        int registro_id;
        String tipo_de_producto;
        ObservableList<String> listaTipoDeProductos = FXCollections.observableArrayList();
        String consultaSQL1 = "SELECT tipo_de_producto, registro_id FROM tipo_producto";
        conexion = new Conexion();
        sqlConexion = conexion.getConnection();
        try {
            Statement tiposDeProductosStatement = sqlConexion.createStatement();
            ResultSet tiposDeProductosResultSet = tiposDeProductosStatement.executeQuery(consultaSQL1);
            while(tiposDeProductosResultSet.next()){
                tipo_de_producto = tiposDeProductosResultSet.getString(1);
                registro_id = tiposDeProductosResultSet.getInt(2);
                String celda = tipo_de_producto;
                listaTipoDeProductos.add(celda);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            sqlConexion = null;
            conexion.desconectar();
        }
        return listaTipoDeProductos;
    }

    public ObservableList<String> obtenerNumerosDeRegistro(){
        String nombre_de_registro;
        ObservableList<String> listaDeRegistros = FXCollections.observableArrayList();
        String consultaSQL1 = "SELECT nombre FROM registro";
        conexion = new Conexion();
        sqlConexion = conexion.getConnection();
        try {
            Statement registroStatement = sqlConexion.createStatement();
            ResultSet registroResultSet = registroStatement.executeQuery(consultaSQL1);
            while(registroResultSet.next()){
                nombre_de_registro = registroResultSet.getString(1);
                String celda = nombre_de_registro;
                listaDeRegistros.add(celda);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            sqlConexion = null;
            conexion.desconectar();
        }
        return listaDeRegistros;
    }
    public ObservableList<Proveedor> obtenerProveedores(){
        ObservableList<Proveedor> listaDeProveedores = FXCollections.observableArrayList();
        String consultaSQL1 = "SELECT id, nombre, telefono, contacto, codigo_de_proveedor, servicio, critico, aprobado, punteo, fecha_aprobacion, fecha_revalidacion FROM proveedores";
        conexion = new Conexion();
        sqlConexion = conexion.getConnection();
        try {
            Statement proveedorStatement = sqlConexion.createStatement();
            ResultSet proveedorResultSet = proveedorStatement.executeQuery(consultaSQL1);
            while(proveedorResultSet.next()){
                int id = proveedorResultSet.getInt(1);
                String nombre = proveedorResultSet.getString(2);
                String telefono = proveedorResultSet.getString(3);
                String contacto = proveedorResultSet.getString(4);
                String codigoProveedor = proveedorResultSet.getString(5);
                String servicio = proveedorResultSet.getString( 6);
                boolean critico = proveedorResultSet.getBoolean(7);
                boolean aprobado = proveedorResultSet.getBoolean(8);
                int punteo = proveedorResultSet.getInt(9);
                LocalDate fechaAprobacion = proveedorResultSet.getDate(10).toLocalDate();
                LocalDate fechaRevalidacion = proveedorResultSet.getDate(11).toLocalDate();
                listaDeProveedores.add(new Proveedor(id, nombre, telefono, contacto, codigoProveedor, servicio, critico, aprobado, punteo, fechaAprobacion, fechaRevalidacion));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            sqlConexion = null;
            conexion.desconectar();
        }
        return listaDeProveedores;
    }


}
