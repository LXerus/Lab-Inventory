package Clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private Connection connection;
    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String USER = "root";
    private static final String PASSORD = "Arisa9713";
    private static final String URL = "jdbc:mysql://localhost:3306/inventario?verifyServerCertificate=false&useSSL=true";

    public Conexion(){
         try{
            connection = DriverManager.getConnection(URL, USER, PASSORD);
            if(connection !=null){
                System.out.println("Conexion exitosa!");
            }
        }catch (SQLException ex){
            System.out.println("Error en la conexion" + ex);
        }
    }

    public Connection getConnection(){
        return connection;
    }

    public  void desconectar(){
        connection = null;
    }
}
